package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.tencent.connect.UserInfo;
import com.tencent.connect.auth.QQToken;
import com.tencent.connect.common.Constants;
import com.tencent.tauth.IUiListener;
import com.tencent.tauth.Tencent;
import com.tencent.tauth.UiError;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobQuery;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.FindListener;
import cn.bmob.v3.listener.SaveListener;

import static cn.bmob.v3.Bmob.getApplicationContext;
import static java.lang.Boolean.TRUE;

public class LoginActivity extends AppCompatActivity {
    private Button btn_login,btn_register;
    private ImageView btn_tencentlog;
    private EditText username,password;
    private Tencent mTencent;
    private String openidString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username=findViewById(R.id.id_username);
        password=findViewById(R.id.id_userpassword);
        Tb();

        btn_login=findViewById(R.id.id_ok);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v1) {
                if (checkEdit() == true) {//判断输入是否不为空
                    if (isConnectInternet() == true) {//联网状态
                        islogin(username.getText().toString(),password.getText().toString());
                    } else {//非联网状态，本地数据库登录

                        //Intent intent = new Intent(loginActivity.this, MainActivity.class);
                        //startActivity(intent);
                        UserService userService = new UserService(LoginActivity.this);

                        boolean flag = userService.Login(username.getText().toString(), password.getText().toString());
                        if (flag) {
                            Toast.makeText(LoginActivity.this, username.getText().toString() + "登录成功！",
                                    Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            intent.putExtra("name", username.getText().toString());//将用户名从loginActicity传给MainActivity
                            startActivity(intent);
                        } else {
                            Toast.makeText(LoginActivity.this, "登录失败！",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
        btn_register=findViewById(R.id.id_register);
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v2) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
        btn_tencentlog=findViewById(R.id.login_qq);
        //btn_tencentlog.setOnClickListener(this);

        mTencent=Tencent.createInstance("1108071146",getApplicationContext());
        btn_tencentlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mTencent.login(LoginActivity.this,"all",new BaseUiListener());
            }
        });
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
                this.exitApp();
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private long exitTime = 0;
    private void exitApp() {
        // 判断2次点击事件时间
        if ((System.currentTimeMillis() - exitTime) > 2000) {
            Toast.makeText(LoginActivity.this, "再按一次退出程序", Toast.LENGTH_SHORT).show();
            exitTime = System.currentTimeMillis();
        } else {
            // finish();
            moveTaskToBack(TRUE);
        }

    }

    public boolean isConnectInternet() {
        ConnectivityManager conManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = conManager.getActiveNetworkInfo();
        if (networkInfo != null) { // 注意，这个判断一定要的哦，要不然会出错
            return networkInfo.isAvailable();
        }
        return false;
    }

    public boolean checkEdit() {
        if (username.getText().toString().equals("")) {
            Toast.makeText(LoginActivity.this, "账户不能为空", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (password.getText().toString().equals("")) {
            Toast.makeText(LoginActivity.this, "密码不能为空", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }


    private class BaseUiListener implements IUiListener {

        @Override
        public void onComplete(Object response) {
            Toast.makeText(getApplicationContext(), "登录成功", Toast.LENGTH_SHORT).show();
            try {
                //获得的数据是JSON格式的，获得你想获得的内容
                //如果你不知道你能获得什么，看一下下面的LOG
                Log.v("----TAG--", "-------------"+response.toString());
                openidString = ((JSONObject) response).getString("openid");
                mTencent.setOpenId(openidString);
                //saveUser("44","text","text",1);
                mTencent.setAccessToken(((JSONObject) response).getString("access_token"),((JSONObject) response).getString("expires_in"));
                Log.v("TAG", "-------------"+openidString);
                //access_token= ((JSONObject) response).getString("access_token");
                //expires_in = ((JSONObject) response).getString("expires_in");
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            QQToken qqToken = mTencent.getQQToken();
            UserInfo info = new UserInfo(getApplicationContext(), qqToken);

            //    info.getUserInfo(new BaseUIListener(this,"get_simple_userinfo"));
            info.getUserInfo(new IUiListener() {
                @Override
                public void onComplete(Object response) {
                    //用户信息获取到了
                    try {
                        Log.v("用户名", ((JSONObject) response).getString("nickname"));
                        Log.v("用户姓名", ((JSONObject) response).getString("gender"));
                        Log.v("UserInfo",response.toString());
                        Intent intent1 = new Intent(LoginActivity.this,MainActivity.class);
                        startActivity(intent1);
                        finish();
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                @Override
                public void onError(UiError uiError) {
                    Log.v("UserInfo","onError");
                }

                @Override
                public void onCancel() {
                    Log.v("UserInfo","onCancel");
                }
            });
        }

        @Override
        public void onError(UiError uiError) {
            Toast.makeText(getApplicationContext(), "onError", Toast.LENGTH_SHORT).show();

        }

        @Override
        public void onCancel() {
            Toast.makeText(getApplicationContext(), "onCancel", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Tencent.onActivityResultData(requestCode, resultCode, data, new BaseUiListener());

        if(requestCode == Constants.REQUEST_API) {
            if(resultCode == Constants.REQUEST_LOGIN) {
                Tencent.handleResultData(data, new BaseUiListener());
            }
        }
    }

    //同步数据库
    public void Tb() {
        if (isConnectInternet() == true) {
            final UserService userService = new UserService(LoginActivity.this);
            userService.DeleteData();
            BmobQuery<User> bq = new BmobQuery<User>();
            bq.findObjects(new FindListener<User>() {
                               @Override
                               public void done(List<User> list, BmobException e) {
                                   for (User us : list) {
                                       SLUser suse = new SLUser();
                                       suse.setUsername(us.getUsername());
                                       suse.setPassword(us.getPassword());
                                       userService.Register(suse);
                                   }
                               }
                           }
            );
            Toast.makeText(LoginActivity.this, "数据库同步成功", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(LoginActivity.this, "网络未连接！", Toast.LENGTH_SHORT).show();
        }
    }

    public void islogin(final String usname, final String pas) {
        BmobQuery<User> bq = new BmobQuery<User>();
        bq.addWhereEqualTo("username", usname);
        bq.findObjects(new FindListener<User>() {
            @Override
            public void done(List<User> object, BmobException e) {
                if(e==null) {
                    if(usname.equals(object.get(0).getUsername())&&pas.equals(object.get(0).getPassword())){//可以登录
                        Toast.makeText(LoginActivity.this, usname + "登录成功", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                        intent.putExtra("name", username.getText().toString());//将用户名从loginActicity传给MainActivity
                        startActivity(intent);
                    }else{//用户名与密码不匹配
                        Toast.makeText(LoginActivity.this, "用户名或密码错误", Toast.LENGTH_SHORT).show();
                    }
                }else{//未知错误
                    Toast.makeText(LoginActivity.this, "用户名或密码错误", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
