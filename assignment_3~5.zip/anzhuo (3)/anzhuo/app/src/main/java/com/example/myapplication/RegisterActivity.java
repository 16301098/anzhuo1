package com.example.myapplication;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

public class RegisterActivity extends AppCompatActivity{
    EditText username;
    EditText password;
    EditText cpassword;
    Button reg_ok;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        username=findViewById(R.id.id_register_username);
        password=findViewById(R.id.id_register_userpassword);
        cpassword=findViewById(R.id.id_register_userpassword_two);

        reg_ok=findViewById(R.id.id_register_ok);
        reg_ok.setOnClickListener(new View.OnClickListener(){
            @Override
            public  void onClick(View v2){
                if(isConnectInternet()==true){//判断是否联网
                    //Toast.makeText(regActivity.this, "网络连接上了", Toast.LENGTH_SHORT).show();
                    if(checkEdit()==true) {//判断输入是否合法
                        //BmobUser user =new BmobUser();
                        User user=new User();
                        user.setUsername(username.getText().toString());
                        user.setPassword(password.getText().toString());

                        user.save(new SaveListener<String>() {
                            @Override
                            public void done(String objectId,BmobException e) {
                                if(e==null){
                                    Toast.makeText(RegisterActivity.this, "注册成功！", Toast.LENGTH_LONG).show();
                                }else{
                                    Toast.makeText(RegisterActivity.this, "注册失败！可能用户名已存在！", Toast.LENGTH_LONG).show();
                                }
                            }
                        });
                    }
                }
                else{
                    Toast.makeText(RegisterActivity.this, "网络连接不可用，请检查网络设置！", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private long exitTime = 0;
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
                this.exitApp();
            }
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    /**
     * 退出程序
     */
    private void exitApp() {
        // 判断2次点击事件时间
        if ((System.currentTimeMillis() - exitTime) > 2000) {
            Toast.makeText(RegisterActivity.this, "再按一次返回登录界面", Toast.LENGTH_SHORT).show();
            exitTime = System.currentTimeMillis();
        } else {
            finish();
        }
    }

    //检查注册信息
    public boolean checkEdit() {
        if (username.getText().toString().equals("")) {
            Toast.makeText(RegisterActivity.this, "账户不能为空", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (password.getText().toString().equals("")) {
            Toast.makeText(RegisterActivity.this, "密码不能为空", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!cpassword.getText().toString().equals(password.getText().toString())) {
            Toast.makeText(RegisterActivity.this, "两次输入的密码不同", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    public boolean isConnectInternet() {

        ConnectivityManager conManager=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE );

        NetworkInfo networkInfo = conManager.getActiveNetworkInfo();

        if (networkInfo != null ){ // 注意，这个判断一定要的哦，要不然会出错
            return networkInfo.isAvailable();
        }
        return false ;
    }


}
