package com.waynell.videolist.widget;

/**
 * Create On 05/01/2017
 * @author Wayne
 */
public enum  PivotPoint {
    LEFT_TOP,
    LEFT_CENTER,
    LEFT_BOTTOM,
    CENTER_TOP,
    CENTER,
    CENTER_BOTTOM,
    RIGHT_TOP,
    RIGHT_CENTER,
    RIGHT_BOTTOM
}
