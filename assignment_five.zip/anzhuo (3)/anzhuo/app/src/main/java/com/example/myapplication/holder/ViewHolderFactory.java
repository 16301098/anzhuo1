package com.example.myapplication.holder;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.example.myapplication.R;
import com.example.myapplication.model.BaseItem;

public class ViewHolderFactory {

    public static BaseViewHolder<? extends BaseItem> buildViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            default:
            case BaseItem.VIEW_TYPE_VIDEO:
                return new VideoViewHolder(LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.video_list_item, parent, false));

        }
    }

}

