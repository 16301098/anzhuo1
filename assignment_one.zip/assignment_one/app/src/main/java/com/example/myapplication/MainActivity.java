package com.example.myapplication;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<ContentModel> mList=new ArrayList<ContentModel>();;
    private ListView mListView;
    private Button btn_menu;
    DrawerLayout mDrawerLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initData();

        mListView=(ListView)findViewById(R.id.left_listview);
        ContentAdapter adapter=new ContentAdapter(this,mList);
        mListView.setAdapter(adapter);

        mDrawerLayout=(DrawerLayout)findViewById(R.id.drawerlayout);

        btn_menu=(Button)findViewById(R.id.left_menu);
        btn_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawerLayout.openDrawer(Gravity.LEFT);
            }
        });

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch(position){
                    case 0:
                        getSupportFragmentManager().beginTransaction().replace(R.id.content,
                            new homepageFragment()).commit();
                        break;
                    case 1:
                        getSupportFragmentManager().beginTransaction().replace(R.id.content,
                            new kaluliFragment()).commit();
                        break;
                    case 2:
                        getSupportFragmentManager().beginTransaction().replace(R.id.content,
                            new wonderFragment()).commit();
                        break;
                    case 3:
                        getSupportFragmentManager().beginTransaction().replace(R.id.content,
                            new sportsFragment()).commit();
                        break;
                    case 4:
                        getSupportFragmentManager().beginTransaction().replace(R.id.content,
                            new pinglunFragment()).commit();
                        break;
                    case 5:
                        getSupportFragmentManager().beginTransaction().replace(R.id.content,
                            new allFragment()).commit();
                        break;
                }
                mDrawerLayout.closeDrawer(Gravity.LEFT);
            }
        });
    }

    private void initData() {
        mList.add(new ContentModel(R.drawable.homepage, "首页", 1));
        mList.add(new ContentModel(R.drawable.kaluli, "进食", 2));
        mList.add(new ContentModel(R.drawable.wonder, "收藏", 3));
        mList.add(new ContentModel(R.drawable.sports, "运动", 4));
        mList.add(new ContentModel(R.drawable.pinglun, "教练", 5));
        mList.add(new ContentModel(R.drawable.all, "登录", 6));
    }
}
