package com.example.myapplication;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
//import android.support.v7.app.AlertController;
import android.support.v4.app.ListFragment;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

//import static android.support.v7.app.AlertController.*;

public class wonderFragment extends ListFragment {
    String[] players = {"Wang Mo", "Li Jian", "刘教练", "David Zhang", "赵武 教练", "Van Persie", "Oscar"};
    String[] experience = {
            "如何选择合适的天气进行合适的运动",
            "手把手教你制作健身餐",
            "远离高热量食物，它会毁掉你的健身",
            "水果——你的健身餐必备品",
            "健身期间你能喝的粥",
            "教你正确挑选到全麦面包",
            "励志健身求队友"
    };
    int[] images = {R.drawable.ic_sun, R.drawable.ic_pan, R.drawable.ic_fruit5, R.drawable.ic_fruit8, R.drawable.ic_boil, R.drawable.ic_breadmachine, R.drawable.athelete_1};

    ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();
    SimpleAdapter adapter;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //MAP
        HashMap<String, String> map = new HashMap<String, String>();

        //FILL
        for (int i = 0; i < players.length; i++) {
            map = new HashMap<String, String>();
            map.put("Player", players[i]);
            map.put("Info",experience[i]);
            map.put("Image", Integer.toString(images[i]));

            data.add(map);
        }

        //KEYS IN MAP
        String[] from = {"Player","Info", "Image"};

        //IDS OF VIEWS
        int[] to = {R.id.nameTxt, R.id.infoTxt, R.id.imageView1};

        //ADAPTER
        adapter = new SimpleAdapter(getActivity().getBaseContext(), data, R.layout.fragment_pinglun_item, from, to);
        setListAdapter(adapter);
        return inflater.inflate(R.layout.fragment_pinglun, container, false);
    }
    @Override
    public void onStart() {
        // TODO Auto-generated method stub
        super.onStart();

        getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> av, View v, int pos,
                                    long id) {
                // TODO Auto-generated method stub

                Toast.makeText(getActivity(), data.get(pos).get("Player"), Toast.LENGTH_SHORT).show();

            }
        });
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        final Fragment fragment = new pinglunFragment();
        final Bundle bundle = new Bundle();
        super.onActivityCreated(savedInstanceState);
        //RecycleListView mRlist;
        // mRlist= getActivity().findViewById(R.id.rview);
        //mRlist.setLayoutManager(new LinearLayoutManager(LinearRecyclerViewActivity.this));


    }
}
