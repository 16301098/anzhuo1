package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import cn.bmob.v3.Bmob;
import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    private Button btn_login,btn_register;
    private EditText username,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btn_login=findViewById(R.id.id_ok);
        btn_login.setOnClickListener(this);
        btn_register=findViewById(R.id.id_register);
        btn_register.setOnClickListener(this);

        username=findViewById(R.id.id_username);
        password=findViewById(R.id.id_userpassword);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.id_ok:
                String log_username = username.getText().toString();
                String log_password = password.getText().toString().trim();

                if (log_username.isEmpty() || log_password.isEmpty()) {
                    Toast.makeText(LoginActivity.this,"密码或账号不能为空!",Toast.LENGTH_SHORT).show();
                    return;
                }
                LoginBean login=new LoginBean();
                login.setPassword(log_password);
                login.setUsername(log_username);

                login.login(new SaveListener<BmobUser>() {

                    @Override
                    public void done(BmobUser ObjectId, BmobException e) {
                        if(e==null){
                            Toast.makeText(LoginActivity.this,"登录成功",Toast.LENGTH_SHORT).show();
                            Intent intent_main = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(intent_main);
                            //通过BmobUser user = BmobUser.getCurrentUser()获取登录成功后的本地用户信息
                            //如果是自定义用户对象MyUser，可通过MyUser user = BmobUser.getCurrentUser(MyUser.class)获取自定义用户信息
                        }else{
                            Toast.makeText(LoginActivity.this,"登录失败",Toast.LENGTH_SHORT).show();
                            //loge(e);

                        }
                    }
                });

                break;
            case R.id.id_register:
                Intent intent_regist = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent_regist);
                break;
        }
    }
}
