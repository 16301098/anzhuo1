package com.example.myapplication;
import cn.bmob.v3.BmobObject;
import cn.bmob.v3.BmobUser;

public class LoginBean extends BmobUser {

}
