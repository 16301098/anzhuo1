package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import cn.bmob.v3.BmobUser;
import cn.bmob.v3.exception.BmobException;
import cn.bmob.v3.listener.SaveListener;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    EditText reg_username;
    EditText reg_password;
    Button reg_ok;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        reg_username=findViewById(R.id.id_register_username);
        reg_password=findViewById(R.id.id_register_userpassword);
        reg_ok=findViewById(R.id.id_register_ok);
        reg_ok.setOnClickListener(this);
    }

    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.id_register_ok:
                String user_num=reg_username.getText().toString();
                String user_password=reg_password.getText().toString().trim();
                // 非空验证
                if (user_num.isEmpty() || user_password.isEmpty()) {
                    Toast.makeText(RegisterActivity.this, "密码或账号不能为空!", Toast.LENGTH_SHORT).show();
                    return;
                }
                // 使用BmobSDK提供的注册功能
                LoginBean myUser=new LoginBean();
                myUser.setUsername(user_num);
                myUser.setPassword(user_password);

                myUser.signUp(new SaveListener<BmobUser>() {
                    @Override
                    public void done(BmobUser objectId, BmobException e) {
                        if(e==null){
                            Toast.makeText(RegisterActivity.this, "注册成功", Toast.LENGTH_SHORT).show();
                        }else{
                            //loge(e);
                            Toast.makeText(RegisterActivity.this, "注册失败", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                finish();
                break;
        }
    }
}
