package com.example.myapplication;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class SportsAdapter extends RecyclerView.Adapter<SportsAdapter.SportsViewHolder> {
    private Context mContext;
    private List<SportsItemContent> list;

    public SportsAdapter(Context context,List<SportsItemContent> List){
        this.mContext=context;
        this.list=List;
    }
    @NonNull
    @Override
    public SportsAdapter.SportsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_sports_item,parent,false);
        SportsAdapter.SportsViewHolder holder=new SportsAdapter.SportsViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull final SportsAdapter.SportsViewHolder holder, final int position) {
        SportsItemContent sportsItemContent=list.get(position);
        holder.imageView.setImageResource(sportsItemContent.getImageView());
        holder.textView.setText(sportsItemContent.getText());
        holder.textView2.setText(sportsItemContent.getInfo());

        //onclick listen
        holder.relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position=holder.getAdapterPosition();
                SportsItemContent sportsItemContent=list.get(position);
                Toast.makeText(v.getContext(),sportsItemContent.getText()+"这是第"+position+"个教练",Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    //length of list
    public int getItemCount() {
        return list.size();
    }

    class SportsViewHolder extends RecyclerView.ViewHolder{
        private ImageView imageView;
        private TextView textView;
        private TextView textView2;
        RelativeLayout relativeLayout;

        public SportsViewHolder(View itemView){
            super(itemView);
            textView=itemView.findViewById(R.id.nameTxt2);
            textView2=itemView.findViewById(R.id.infoTxt2);
            imageView=itemView.findViewById(R.id.imageView2);
            relativeLayout=itemView.findViewById(R.id.layoutsports);
        }
    }
}
