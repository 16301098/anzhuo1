package com.example.myapplication;

public class SportsItemContent {
    private int imageView;
    private String name;
    private String info;

    public SportsItemContent(){

    }
    public SportsItemContent(int imageView,String name,String info){
        this.imageView=imageView;
        this.name=name;
        this.info=info;
    }

    public int getImageView(){
        return imageView;
    }

    public void setImageView(int imageView){
        this.imageView=imageView;
    }

    public String getText(){
        return name;
    }

    public void setText(String text){
        this.name=text;
    }

    public String getInfo(){
        return info;
    }

    public void setInfo(String info){
        this.info=info;
    }
}
