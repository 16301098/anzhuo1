package com.example.myapplication;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.myapplication.SportsItemContent;
import java.util.ArrayList;
import java.util.List;

public class sportsFragment extends Fragment {
    private RecyclerView mSports;
    private List<SportsItemContent> list=new ArrayList<>();
    private RecyclerView.Adapter sportsAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_sports,container,false);
        initData();

        mSports=view.findViewById(R.id.rv_sports);
        sportsAdapter=new SportsAdapter(getActivity(),list);

        mSports.setLayoutManager(new LinearLayoutManager(getActivity (),LinearLayoutManager.VERTICAL,false));
        mSports.setItemAnimator(new DefaultItemAnimator());
        mSports.setAdapter(sportsAdapter);
        mSports.addItemDecoration(new DividerItemDecoration(getActivity(),DividerItemDecoration.VERTICAL));

        return view;
        //return inflater.inflate(R.layout.fragment_sports, container, false);
    }

    private void initData() {
        String[] players = {"Wang Mo", "Li Jian", "刘教练", "David Zhang", "赵武 教练", "Van Persie", "Oscar"};
        String[] experience = {
                "Perfection is not attainable, but if we chase perfection we can catch excellence",
                "Health & Fitness Lifestyle Transformation.Gym doesn't change live, People do.",
                "If we chase perfection we can catch excellence",
                "Gym doesn't change live, People do.",
                "An accomplished fitness trainer with seven years of experience n hand",
                "Gym doesn't change live, People do.",
                "Gym doesn't change live, People do."
        };
        int[] images = {R.drawable.trainer1, R.drawable.trainer2, R.drawable.trainer3, R.drawable.trainer4, R.drawable.trainer5, R.drawable.trainer2, R.drawable.athelete_1};


        for (int i = 0; i < players.length; i++) {
            SportsItemContent coachlist=new SportsItemContent(images[i],players[i],experience[i]);
            list.add(coachlist);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        final Fragment fragment = new sportsFragment();
        final Bundle bundle = new Bundle();
        super.onActivityCreated(savedInstanceState);

    }
}
